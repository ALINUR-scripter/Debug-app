# ALILauncher

Minecraft: Java Edition launcher for Android (`com.alilauncher.app`).
Based on [PojavLauncher](https://github.com/PojavLauncherTeam/PojavLauncher) (LGPL-3.0, see LICENSE).

- App name: **ALILauncher**
- Package: `com.alilauncher.app`
- Game data: `Android/data/com.alilauncher.app/files` (`.minecraft`, `controlmap`, `latestlog.txt`)
- Own midnight-indigo / amber theme and icon

## Build the APK
Push this folder to a GitHub repo and open **Actions → ALILauncher build → Run workflow**.
The APK appears under the run's artifacts (`app-debug`: `app-debug.apk`).

Local build needs Android SDK + NDK 25.2.9519653, JRE runtimes in
`app_pojavlauncher/src/main/assets/components/*` and `ltw-release.aar` in `app_pojavlauncher/libs` (see the workflow).
